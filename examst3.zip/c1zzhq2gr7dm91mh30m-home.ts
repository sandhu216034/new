// 1. Define an enum for device statuses
enum DeviceStatus {  
    On,  
    Off,  
    Standby  
}  

// 2. Define a tuple type for SmartDevice
type SmartDevice = [  
    deviceName: string,  
    deviceType: string,  
    status: DeviceStatus  
];  

// 3. Function to toggle device status with valid transitions
function toggleDeviceStatus(device: SmartDevice, newStatus: DeviceStatus): SmartDevice {  
    let [deviceName, deviceType, currentStatus] = device;  

    // Valid transitions: Off → On, On → Standby, Standby → On or Off
    const validTransitions: Record<DeviceStatus, DeviceStatus[]> = {  
        [DeviceStatus.On]: [DeviceStatus.Standby, DeviceStatus.Off],  
        [DeviceStatus.Off]: [DeviceStatus.On],  
        [DeviceStatus.Standby]: [DeviceStatus.On, DeviceStatus.Off]  
    };  

    // Check if the transition is valid
    if (!validTransitions[currentStatus].includes(newStatus)) {  
        console.log(`Invalid transition from ${DeviceStatus[currentStatus]} to ${DeviceStatus[newStatus]}`);  
        return device; // Return unchanged device
    }  

    // Return the updated device tuple with the new status
    return [deviceName, deviceType, newStatus];  
}  

// Example usage  
let myDevice: SmartDevice = ["Living Room Light", "Light", DeviceStatus.Off];  
console.log(toggleDeviceStatus(myDevice, DeviceStatus.On));      // Valid transition  
console.log(toggleDeviceStatus(myDevice, DeviceStatus.Standby)); // Invalid transition  
