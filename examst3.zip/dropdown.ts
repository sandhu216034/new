// dropdown.ts
const selectElement = document.getElementById("countrySelect") as HTMLSelectElement;
const outputElement = document.getElementById("selectedCountry") as HTMLParagraphElement;

selectElement.addEventListener("change", () => {
  outputElement.textContent = `Selected Country: ${selectElement.value}`;
});
