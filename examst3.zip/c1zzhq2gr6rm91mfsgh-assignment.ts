enum BookStatus {
    Available,
    CheckedOut,
    Reserved,
  }
  
  type Book = [string, string, number, BookStatus];
  
  function borrowBook(book: Book): string {
    let [title, author, isbn, status] = book;
  
    if (status === BookStatus.Available) {
      book[3] = BookStatus.CheckedOut;
      return `You have successfully borrowed "${title}".`;
    }
  
    if (status === BookStatus.CheckedOut) {
      return `Sorry, "${title}" is already checked out.`;
    }
  
    if (status === BookStatus.Reserved) {
      return `Sorry, "${title}" is reserved and cannot be borrowed.`;
    }
  
    return "Invalid book status.";
  }
  
  // Test cases
  let book1: Book = ["The Great Gatsby", "F. Scott Fitzgerald", 123456789, BookStatus.Available];
  let book2: Book = ["1984", "George Orwell", 987654321, BookStatus.CheckedOut];
  let book3: Book = ["To Kill a Mockingbird", "Harper Lee", 567890123, BookStatus.Reserved];
  
  console.log(borrowBook(book1)); // Should allow borrowing
  console.log(borrowBook(book1)); // Should say the book is checked out
  console.log(borrowBook(book2)); // Should say the book is checked out
  console.log(borrowBook(book3)); // Should say the book is reserved
  