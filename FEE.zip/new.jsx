//Hide

import React from "react";
import { useState } from "react";
function ToggleMessage(){
    const[isVisible,setIsVisible]=useState();
  function handleClick(){
    setIsVisible(!isVisible);
  }
  let message;
  if(isVisible){
    message=<p>Hello message for baby</p>
  }
    return(
  <div>
    <button onClick={handleClick}>Show/Hide Message</button>
    {message}
  </div>
    );
}
export default ToggleMessage;

//Click Tracker
import React, {useState} from "react";

function ClickTracker(){
    const[count,setCount]=useState(0);
    
    return(
        <div>
            <button onClick={()=>setCount(count+1)}>Click me!</button>
            <p>You clicked {count} times</p>
        </div>
    )
}
export default ClickTracker;

//Text to input
import React, { useState } from 'react';

function TextInputDisplay() {
  const [text, setText] = useState('');

  return (
    <div>
      <input onChange={(e) => setText(e.target.value)} />
      <p>You typed: {text}</p>
    </div>
  );
}

export default TextInputDisplay;

//Theme Toggler
import React, { useState, useEffect } from 'react';

function ThemeToggler() {
  const [theme, setTheme] = useState('light');

  // Load theme from localStorage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) setTheme(savedTheme);
  }, []);

  // Save theme to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('theme', theme);
    document.body.className = theme; // Optional: apply class to body
  }, [theme]);

  // Toggle theme handler
  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  return (
    <div>
      <button onClick={toggleTheme}>Toggle Theme</button>
      <p>Current theme: {theme}</p>
    </div>
  );
}

export default ThemeToggler;

//Character count
import React, { useState } from 'react';

function CharacterCounter() {
  const [inputText, setInputText] = useState('');

  const handleChange = (e) => {
    setInputText(e.target.value);
  };

  return (
    <div>
      <textarea 
        value={inputText} 
        onChange={handleChange} 
        placeholder="Type here..." 
      />
      <p>Character count: {inputText.length}</p>
    </div>
  );
}

export default CharacterCounter;
