//Time out
function wait(ms){
    return new Promise((resolve)=>{
        setTimeout(()=>{
            resolve();
        },ms);
    });
}
wait(2000).then(()=>{
    console.log("Waited for 2 seconds");
})

//Countdown
function countdown(number){
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log(number);
            resolve();
        },1000);
    });
}
countdown(3)
    .then(()=>countdown(2))
    .then(()=>countdown(1))
    .then(()=>{
        console.log("Lift Off!");
    });

//delayed msg
function delayedMessage(message,ms,shouldCancel){
    return new Promise((resolve,reject)=>{

        setTimeout(()=>{
           if(shouldCancel){
            reject("Operation Cancelled");
           }
           else{
            resolve(message);
           }
        },ms);
    });
}
delayedMessage("Hi mttrhuh",2000,false)
.then((msg)=>{
    console.log(msg)
})
.catch((err)=>{
    console.log(err)
})
//Calculation
Promise.resolve(10)
   .then((num)=>num*30)
   .then((num)=>num+4)
   .then((num)=>num/2)
   .then((num)=>{
    console.log(num);
   });

//Fetch item
function fetchitem(itemName,delay){
    return new Promise((resolve)=>{
        setTimeout(()=>{
            resolve("Fetched:"+itemName);
        },delay);
    });
}

fetchitem("User",1000)
   .then((msg)=>{
    console.log(msg);
    return fetchitem("Posts",2000);
   })
   .then((msg)=>{
    console.log(msg);
    return fetchitem("Comments",1500);
   })
   .then((msg)=>{
    console.log(msg);
   });

   //sum of property
  return new Promise((resolve, reject) => {
    let sum = 0;
    for (const obj of arr) {
      if (!obj.hasOwnProperty(property)) {
        return reject("Property not found in all objects");
      }
      sum += obj[property];
    }
    resolve(sum);
  });
