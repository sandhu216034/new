//Formtable
import React, {useState} from "react";

function SimpleForm(){
    const[name,setName]=useState(' ');
    const[submittedname,setSubmittedname]=useState(' ');
    function handleSubmit(e){
            e.preventDefault();
            setSubmittedname(name);
            setName(' ');
    }
    // let message=null;
    // if(submittedname){
    //     message=<p>Submiited: {submittedname}</p>
    // }
    return(
        <div>
            <form onSubmit={handleSubmit}>
                <input type="text" value={name} onChange={(e)=>setName(e.target.value)}  placeholder="EnterName"/>
                <button type="submit">Submit</button>
            </form>

            <p>Submitted: {submittedname}</p>
        </div>

    );
}
export default SimpleForm;

//LocalForm
import React,{useState} from "react";

function UserFormTable(){
    //const[user,setUser]=useState([]);
    //for local
      const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("user");
    // return saved ? JSON.parse(saved) : [];
    if(saved!=null){
      return JSON.parse(saved)
    }
    else{
      return []
    }
  });

  
    const[name,setName]=useState('');
    const[email,setEmail]=useState('');
    const[grade,setGrade]=useState('');
    function handleSubmit(e){
        e.preventDefault();
        const newUser={
            name,
            email,
            grade,
        };
       // setUser([...user,newUser]);
       //for local
        const updatedUsers = [...user, newUser];

    // 2. Update state and localStorage
    setUser(updatedUsers);
    localStorage.setItem("user", JSON.stringify(updatedUsers));


        setName('');
        setEmail('');
        setGrade('');

    };

    return(
        <div>
          <h2>Add User</h2>
          <form onSubmit={handleSubmit}>
              <input type="text" value={name} placeholder="name" onChange={e=>setName(e.target.value)} required/>
              <input type="email" placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} required/>
              <input type="text" placeholder="grade" value={grade} onChange={e=>setGrade(e.target.value)} required/>
              <button type="submit">Submit</button>

          </form>
          <table border="2">
              <thead>
                <tr>
                    <th>name</th>
                    <th>email</th>
                    <th>grade</th>
                </tr>
              </thead>
              <tbody>
                {user.map(user=>(
                    <tr>
                        <td>{user.name}</td>
                        <td>{user.email}</td>
                        <td>{user.grade}</td>
                    </tr>
                )

                )}
              </tbody>
          </table>
        </div>
    )
}
export default UserFormTable;

//