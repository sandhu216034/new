//Calculate Area
function calculateArea(width:number,height:number):number{
     return width*height;
}

//For Valid
let area=calculateArea(5,10);
console.log("Area",area);


//Form
function handleForm(event:Event):void{
    event.preventDefault();
    const name=(document.getElementById('name')as HTMLInputElement).value;
    const email=(document.getElementById('email')as HTMLInputElement).value;

    console.log('Name: ',name);
    console.log('Email: ',email);
}


const form=document.getElementById('form') as HTMLFormElement;
form.addEventListener('submit',handleForm);

//Greeting
function updateGreeting(text:string):void{
    const elem=document.getElementById('greet');
    if(elem!==null){
        elem.innerText=text;

    }
    else{
console.error("Element with id 'greeting' not found.");
    }
}
updateGreeting("Welcome to typescript greeting");

// Type array Products
type Product={
    id:number,
    name:string,
    price:number,
};
const products:Product[]=[
    {id:1,name:"smay",price:200},
    {id:2,name:"smarth",price:400},
    {id:3,name:"rohit",price:300}
]
function logProducts(products:Product[]):void{
    products.forEach(element => {
        console.log(`Name: ${element.name}`)
        console.log(`Price: ${element.price}`)
    });
}
logProducts(products);

//User Interface
interface User{
  id:number,
  name:string,
  isActive:boolean,
};
 function printUser(user:User):void{
     console.log(`ID :  ${user.id}`)
     console.log(`Name: ${user.name}`)
     console.log(`Status: ${user.isActive}`)

 };
 const sampleUser:User={
    id:11,
    name:"shyamff",
    isActive:true,
 };
 printUser(sampleUser);

 //Value type narrowing
 function printValue(value:string|number):void{
    if(typeof value=== 'string'){
        console.log(value.toUpperCase());
    }
    else if(typeof value === 'number'){
        console.log(value*2);
    }
    else{
        console.log("error type");
    }
}

printValue('Hi Buddy');
printValue(25);

//html toogle background
<!DOCTYPE html>
<html>
<head>
  <title>Toggle Class</title>
  <style>
    #box {
      width: 100px;
      height: 100px;
      background-color: grey;
      margin-top: 10px;
    }

    .active {
      background-color: green;
    }
  </style>
</head>
<body>
  <button id="toggleBtn">Toggle Box Color</button>
  <div id="box"></div>

  <script src="script.js"></script>
</body>
</html>

function toggleClass(): void {
  const box = document.getElementById('box');
  if (box) {
    box.classList.toggle('active');
  }
}

document.getElementById('toggleBtn')!.addEventListener('click', toggleClass);
