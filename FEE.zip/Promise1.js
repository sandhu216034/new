//CurrTime async await
function wait(delay){
    return new Promise((resolve)=>{
      setTimeout(()=>{
       console.log("wait over for 2 sec");
       resolve();
      },delay);
    })
}


async function currTime(){
    console.log("Start Time: ", new Date().toLocaleTimeString());
    await wait(2000);
    console.log("End Time: ", new Date().toLocaleTimeString());
}
currTime();

//runsteps
function stepOne(){
    return new Promise((resolve)=>{
        setTimeout(()=>{
            resolve("step 1 done");
        },1000);
    });
}
function stepTwo(){
    return new Promise((resolve)=>{
        setTimeout(()=>{
            resolve("step 2 done");
        },1000);
    });
}
function stepThree(){
    return new Promise((resolve)=>{
        setTimeout(()=>{
            resolve("step 3 done");
        },1000);
    });
}


async function runSteps(){
    const stepone= await stepOne();
    console.log(stepone);
    const steptwo= await stepTwo();
    console.log(steptwo);
    const stepthree= await stepThree();
    console.log(stepthree);
}

runSteps();

//Username
function isUsernameAvailable(name){
    return new Promise((resolve,reject)=>{
        if(name.toLowerCase()==="admin"){
            reject("Name Taken");
        }
        else{
            resolve(true);
        }
    });
}

async function checkAvailability(name){
  try{
     await isUsernameAvailable(name);
     console.log("Available");

  }
  catch(e){
    console.log("Error: ",e);
  }
}
checkAvailability("Shambbhu");
checkAvailability("Admin");

//Even Number
function filterEvenNumbers(arr) {
  return new Promise((resolve, reject) => {
    const evenNumbers = arr.filter(num => num % 2 === 0);
    
    if (evenNumbers.length > 0) {
      resolve(evenNumbers);
    } else {
      reject("No even numbers found");
    }
  });
}

