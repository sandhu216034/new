// app.ts
const postContent = document.getElementById('postContent') as HTMLTextAreaElement;
const charCount = document.getElementById('charCount') as HTMLSpanElement;
const warningMsg = document.getElementById('warningMsg') as HTMLDivElement;

postContent.addEventListener('input', () => {
  const length = postContent.value.length;
  charCount.textContent = length.toString();

  if (length > 200) {
    warningMsg.textContent = 'Character limit exceeded!';
  } else {
    warningMsg.textContent = '';
  }
});
