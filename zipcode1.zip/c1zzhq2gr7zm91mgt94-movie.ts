
// Define an enum for seat types
enum SeatType {  
    Regular,  
    Premium,  
    VIP  
}  

// Define a tuple type for Ticket
type Ticket = [  
    movieName: string,  
    seatNumber: number,  
    seatType: SeatType,  
    price: number  
];  

// Function to calculate discount based on seat type
function calculateDiscount(ticket: Ticket): number {  
    let [_, __, seatType, price] = ticket; // Destructure the ticket tuple  
    let discount = 0;  

    // Apply discount based on seat type
    if (seatType === SeatType.Premium) {  
        discount = 0.10 * price;  
    } else if (seatType === SeatType.VIP) {  
        discount = 0.20 * price;  
    }  

    return price - discount; // Return final price after discount  
} 