import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'

const Productlist = () => {
const [selectedProduct,setSeletedProduct]=useState(null)
const [product,setProduct]=useState(null)

  async function fetchData(){
        const data =await fetch("https://fakestoreapi.com/products")
       const res = await data.json()
    setProduct(res)

    }
function openmodal(obj){
    setSeletedProduct(obj)
}
function closemodal(){
    setSeletedProduct(null)
}
console.log(selectedProduct)

useEffect(()=>{
    fetchData()
},[])
  return (
    <div style={{
        display:'flex',
        flexWrap:'wrap',
        gap:"10px",
        justifyContent:"center"
    }}>
        {
           product && product.map((obj)=>(
                <div style={{
                    width:"200px",
                    display:'flex',
                    flexDirection:'column',
                    alignItems:"center",
                    
                }}>
                    <img width="150px" height="180px" src={obj.image} alt="" style={{
                        objectFit:"contain"
                    }}/>
                    <div style={{display:"flex",flexDirection:"column",gap:"5px",alignItems:"center"}}>
                    <h4 style={{padding:0,margin:0}}>{obj.title}</h4>
                    <p style={{padding:0,margin:0}}>₹ {obj.price}</p>
                    <p style={{padding:0,margin:0}}>{obj.category}</p>
                    <button onClick={()=>{openmodal(obj)}}
                        style={{
                            padding:"5px 15px",
                            fontSize:"16px",
                            border:"1px solid #ddd"
                        }}
                        >View Details</button>
                    </div>
                </div>
            ))
        }
        
        {
            selectedProduct && 
            <div style={{
                width:"500px",
                border:"1px solid #ddd",
                padding:"10px 15px",
                position:"absolute",
                top:"50%",
                left:"50%",
                translate:"-50% -50%",
                backgroundColor:"white",
                boxShadow:"0px 5px 5px #ddd",
                display:"flex",
                flexDirection:"column",
                justifyContent:"center",
                alignItems:"center",
                borderRadius:"5px"

            }}>
                <h3>Description : {selectedProduct?.description}</h3>
                <h2>Rating : {selectedProduct?.rating?.rate}</h2>
                <button 
                style={{
                    padding:"10px 15px",
                    fontSize:"20px"
                }}
                onClick={closemodal}>close</button>
                
            </div>
        }

    </div>
  )
}

export default Productlist