import React from 'react'
import { useState } from "react"

const Feedbackform = () => {

    const [data,setData]=useState([])
  const [formData,setFormData]=useState({
    name:"",
    department:"",
    feedback:"",
    rating:""
  });
  function handleSubmit(e){
    e.preventDefault();
    if(!formData.name) return
    if(!formData.department) return
    if(!formData.feedback) return
    if(!formData.rating) return  
    setData([...data,formData])
  }

  return (
    <>
        <form onSubmit={handleSubmit}>
          <label htmlFor="">Name : </label>
          <input type="text" onChange={(e)=>setFormData({...formData,name:e.target.value})}/><br /><br />

          <label htmlFor="">Department : </label>
          <select name="department" onChange={(e)=>setFormData({...formData,department:e.target.value})}>
            <option value="HR">HR</option>
            <option value="Engineering">Engineering</option>
            <option value="Marketing">Marketing</option>
            <option value="Finance">Finance</option>
          </select><br /><br />
          <label htmlFor="">Feedback : </label>
          <textarea name="feedback" onChange={(e)=>setFormData({...formData,feedback:e.target.value})}></textarea>
          <br />
          <br />
          <label htmlFor="">Rating : </label>
          {
            [1,2,3,4,5].map((num)=>(
              <label>
                <input type="radio" name="rating" value={num} onChange={(e)=>setFormData({...formData,rating:e.target.value})}/>
                {num}
              </label>
            ))
          }
          <br /><br />
          <button>Submit</button>
      </form>

      <table border={1}>
        <thead>
        <tr>
          <th>Name</th>
          <th>Department</th>
          <th>Feedback</th>
          <th>Rating</th>
        </tr>
        </thead>
        <tbody>
        {
          data.map((obj)=>{
            <tr>
              <td>{obj.name}</td>
              <td>{obj.department}</td>
              <td>{obj.feedback}</td>
              <td>{obj.rating}</td>
            </tr>
})
        }
        </tbody>
        
      </table>
    </>
  )
}

export default Feedbackform