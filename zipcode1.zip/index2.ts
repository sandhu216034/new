const age=document.getElementById('ageInput') as HTMLInputElement;
let error=document.getElementById('errorMsg') as HTMLDivElement

age.addEventListener('input',()=>{
    const value=age.value;
    const numeric=/^\d*$/.test(value);
    if(!numeric){
        error.textContent='Please enter only numeric characters.';
    }
    else{
        error.textContent=" ";
    }
});